import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CustomerComponent } from './customer/customer.component';
import {HttpClient, HttpClientModule} from '@angular/common/http';
import {CustomerService} from './customer/customer.service';
import {Observable} from 'rxjs';
import { AdvisorComponent } from './advisor/advisor.component';

@NgModule({
  declarations: [
    AppComponent,
    CustomerComponent,
    AdvisorComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [
      CustomerService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }

export class Advisor {
    private advisorId: number;
    private name: String;
    private speciality: String;
}

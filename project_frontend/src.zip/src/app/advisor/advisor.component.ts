import { Component, OnInit } from '@angular/core';
import {AdvisorService} from './advisor.service';
import {Advisor} from './advisor';

@Component({
  selector: 'app-advisor',
  templateUrl: './advisor.component.html',
  styleUrls: ['./advisor.component.scss']
})
export class AdvisorComponent implements OnInit {

  advisors: Advisor[];
  constructor(private advisorSrv: AdvisorService) {
    this.advisorSrv.getAdvisors().then(
        (a: Advisor[]) => {
          this.advisors = a;
        }
    );
  }

  ngOnInit() {
  }

}

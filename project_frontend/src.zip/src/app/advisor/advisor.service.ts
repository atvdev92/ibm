import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AdvisorService {

  constructor(private http: HttpClient) { }

  getAdvisors() {
    return this.http.get('http://35.238.35.187/ibm/api/v1/advisor').toPromise();
  }
}

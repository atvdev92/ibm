export class Customer {
    private customerId: number;
    private name: String;
    private address: String;
    private city: String;
    private ph_number: number;
    private cards_counter: number;
}

package ibm.test.ibmspringtest.bootstrap;

import ibm.test.ibmspringtest.domain.*;
import ibm.test.ibmspringtest.repositories.AdvisorRepository;
import ibm.test.ibmspringtest.repositories.CardRepository;
import ibm.test.ibmspringtest.repositories.ConsumptionRepository;
import ibm.test.ibmspringtest.repositories.CustomerRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
public class BootstrapData implements CommandLineRunner {

    private final CustomerRepository customerRepository;
    private final CardRepository cardRepository;
    private final ConsumptionRepository consumptionRepository;
    private final AdvisorRepository advisorRepository;

    public BootstrapData(CustomerRepository customerRepository, CardRepository cardRepository, ConsumptionRepository consumptionRepository, AdvisorRepository advisorRepository) {
        this.customerRepository = customerRepository;
        this.cardRepository = cardRepository;
        this.consumptionRepository = consumptionRepository;
        this.advisorRepository = advisorRepository;
    }

    @Override
    public void run(String... args) throws Exception {

        System.out.println("::::::Cargando datos iniciales");

        /**
         * Definición de datos de clientes
         * **/

        Customer customer1 = new Customer(1,"Heberth Tobar","Dirección 1", "Jamundi", 3188754455L,2);
        customerRepository.save(customer1);

        Customer customer2 = new Customer(2,"Alfonso Tobar","Dirección 2", "Jamundi", 31887334455L,1);
        customerRepository.save(customer2);

        Customer customer3 = new Customer(3,"Mercedes Vega","Dirección 3", "Jamundi", 31345678999L,2);
        customerRepository.save(customer3);


        /**
         * Definición de datos de tarjetas
         * **/

        System.out.println("::::::Clientes precargados: " + customerRepository.count());

        System.out.println("::::::Asignando Tajetas a los clientes");

        Card card1 = new Card(1,1,1111111111111111L,123,"VISA");
        cardRepository.save(card1);

        Card card2 = new Card(2,1,3333333333333333L,113,"VISA BLACK");
        cardRepository.save(card2);

        Card card3 = new Card(3,2,8888888888888888L,555,"VISA");
        cardRepository.save(card3);

        Card card4 = new Card(4,3,2222222222222222L,111,"AMERICAN EXPRESS");
        cardRepository.save(card4);

        Card card5 = new Card(5,3,7777777777777777L,000,"MASTER CARD");
        cardRepository.save(card5);

        System.out.println("::::::Se ha asignado las tarjetas a los clientes");

        /**
         * Definición de los consumos
         */

        System.out.println("::::::Cargando Consumos");

        Consumption consumption1 = new Consumption(1 ,1,new Date("2018/01/01"),"SuperInter",24500);
        consumptionRepository.save(consumption1);

        Consumption consumption2 = new Consumption(2, 2, new Date("2018/06/01"),"Addidas",270000);
        consumptionRepository.save(consumption2);

        Consumption consumption3 = new Consumption(3, 18, new Date("2018/06/01"),"Addidas",270000);
        consumptionRepository.save(consumption3);

        System.out.println("::::::Consumos cargados");

        /**
         * Definición de los Asesores**/
        System.out.println("::::::Cargando asesores");

        Advisor adv1 = new Advisor(1,"Juan David Cardona","Especialista en creditos de consumo");
        advisorRepository.save(adv1);

        Advisor adv2 = new Advisor(2,"Jesus Mejía","Especialista en cobranza");
        advisorRepository.save(adv2);
    }
}

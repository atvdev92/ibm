package ibm.test.ibmspringtest.domain;

import lombok.Data;

import javax.persistence.*;

@Data
@Entity
@Table(name = "Advisor")
public class Advisor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer advisorId;
    private String name;
    private String speciality;

    public Advisor() {
    }

    public Advisor(Integer advisorId,String name, String speciality) {
        this.advisorId = advisorId;
        this.name = name;
        this.speciality = speciality;
    }
}

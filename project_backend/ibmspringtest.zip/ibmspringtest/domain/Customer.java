package ibm.test.ibmspringtest.domain;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.util.List;

@Data
@Entity
public class Customer {

    /**
     *
     *
     * Aquí se definen las propiedades del cliente correspondientes a:
     * Nombre, Dirección, Ciudad, Teléfono, Cantidad de tarjetas, y los numeros de cada tarjeta
     *
     * **/

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int customerId;
    private  String name;
    private String address;
    private String city;
    private float ph_number;
    private int cards_counter;

    public Customer() {
    }

    public Customer(int customerId,String name, String address, String city, float ph_number, int cards_counter) {
        this.name = name;
        this.address = address;
        this.city = city;
        this.ph_number = ph_number;
        this.cards_counter = cards_counter;
    }
}

package ibm.test.ibmspringtest.domain;

import lombok.Data;
import org.hibernate.annotations.NaturalId;
import org.springframework.stereotype.Indexed;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

@Data
@Entity
@Table(name = "Card")
public class Card {
    /**
     *
     * Aquí se definen los atributos de la tarjeta
     *
     * **/


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int cardId;
    private int customerId;
    private long numberCode;
    private int ccv;
    private String card_type;

    public Card() {
    }

    public Card(@NotNull int cardId, @NotNull int customerId, long numberCode, int ccv, String card_type) {
        this.cardId = cardId;
        this.customerId = customerId;
        this.numberCode = numberCode;
        this.ccv = ccv;
        this.card_type = card_type;
    }


}

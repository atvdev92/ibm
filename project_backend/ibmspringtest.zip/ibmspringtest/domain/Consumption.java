package ibm.test.ibmspringtest.domain;

import lombok.Data;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.Date;

@Data
@Entity
@Table(name = "Consumption")
public class Consumption{

    /**
     *
     * Aquí se definen los atributos de los consumos
     *
     * **/

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer consumpId;
    private Integer cardId;
    private Date date;
    private String description;
    private float amount;

    public Consumption() {
    }

    public Consumption(@NotNull Integer consumpId, @NotNull Integer cardId, Date date, String description, float amount) {
        this.consumpId = consumpId;
        this.cardId = cardId;
        this.date = date;
        this.description = description;
        this.amount = amount;
    }
}

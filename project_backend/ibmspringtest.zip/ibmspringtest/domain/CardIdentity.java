package ibm.test.ibmspringtest.domain;

import lombok.Data;

import javax.persistence.Embeddable;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

@Data
@Embeddable
public class CardIdentity implements Serializable {

    @NotNull
    private Integer cardId;

    @NotNull
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer customerId;

    public CardIdentity() {
    }

    public CardIdentity(@NotNull int cardId, @NotNull int customerId) {
        this.cardId = cardId;
        this.customerId = customerId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        CardIdentity that = (CardIdentity) o;

        if (!cardId.equals(that.cardId)) return false;
        return customerId.equals(that.customerId);
    }

    @Override
    public int hashCode() {
        int result = cardId.hashCode();
        result = 31 * result + customerId.hashCode();
        return result;
    }

}

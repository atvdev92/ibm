package ibm.test.ibmspringtest.controllers;


import ibm.test.ibmspringtest.domain.Customer;
import ibm.test.ibmspringtest.services.CustomerService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.CrossOrigin;
import java.util.List;

@RestController
@RequestMapping(CustomerController.ORIGIN_URL_CUSTOMER)
public class CustomerController {

    public static final String ORIGIN_URL_CUSTOMER = "/api/v1/customer";

    private  final CustomerService customerService;

    public CustomerController(CustomerService customerService) {

        this.customerService = customerService;
    }


    @CrossOrigin(origins = "*")
    @GetMapping
    List<Customer> getAllCustomer(){
        return customerService.findAllCustomers();
    }

    @CrossOrigin(origins = "*")
    @GetMapping("/{id}")
    public  Customer getCustomerById(@PathVariable int id){
        return  customerService.findCustumerById(id);
    }

    @CrossOrigin(origins = "*")
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Customer saveCustomer(@RequestBody Customer customer){
        return customerService.saveCustomer(customer);
    }

    @CrossOrigin(origins = "*")
    @PutMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Customer updateCustomer(@RequestBody Customer customer){
        return  customerService.saveCustomer(customer);
    }

    @CrossOrigin(origins = "*")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.ACCEPTED)
    public void deleteCustomer(@PathVariable int id){
        customerService.deleteCustomer(id);
    }
}

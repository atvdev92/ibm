package ibm.test.ibmspringtest.controllers;

import ibm.test.ibmspringtest.domain.Card;
import ibm.test.ibmspringtest.services.CardService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.CrossOrigin;



import java.util.List;

@RestController
@RequestMapping(CardController.ORIGIN_URL_CARD)
public class CardController {

    public static final String ORIGIN_URL_CARD = "/api/v1/card";

    private final CardService cardService;

    public CardController(CardService cardService) {
        this.cardService = cardService;
     }

     @CrossOrigin(origins = "*")
    @GetMapping
    List<Card> getAllCard(){
        return cardService.findAllCards();
    }

    @CrossOrigin(origins = "*")
    @GetMapping("/{id}")
    public Card getCardById(@PathVariable Integer id){
        return cardService.findCardById(id);
    }

    @CrossOrigin(origins = "*")
    @GetMapping("/{id}/c")
    public List<Card> findByCustomerId(@PathVariable Integer id){
        return cardService.findByCustomerId(id);
    }

    @CrossOrigin(origins = "*")
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Card saveCard(@RequestBody Card card){
        return cardService.saveCard(card);
    }

    @CrossOrigin(origins = "*")
    @PutMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Card updateCard(@RequestBody Card card){
        return cardService.saveCard(card);
    }

    @CrossOrigin(origins = "*")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.ACCEPTED)
    public void deleteCard(@PathVariable Integer id){
        cardService.deleteCard(id);
    }

}

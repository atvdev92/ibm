package ibm.test.ibmspringtest.controllers;

import ibm.test.ibmspringtest.domain.Consumption;
import ibm.test.ibmspringtest.services.ConsumptionService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.CrossOrigin;

import java.util.List;

@RestController
@RequestMapping(ConsumptionController.ORIGIN_URL_COSUMPTION)
public class ConsumptionController {

    public static final String ORIGIN_URL_COSUMPTION = "/api/v1/consumption";

    private final ConsumptionService consumptionService;

    public ConsumptionController(ConsumptionService consumptionService) {
        this.consumptionService = consumptionService;
    }


     @CrossOrigin(origins = "*")
    @GetMapping
    List<Consumption> getAllConsumption(){
        return consumptionService.findAllConsumtions();
    }

     @CrossOrigin(origins = "*")
    @GetMapping("/{id}")
    public Consumption getConsumpById(@PathVariable Integer id){
        return consumptionService.findConsumptionById(id);
    }

     @CrossOrigin(origins = "*")
    @GetMapping("/{id}/conp")
    public List<Consumption> findByCardId(@PathVariable Integer id){
        return consumptionService.findByCardId(id);
    }

     @CrossOrigin(origins = "*")
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Consumption saveConsumption(@RequestBody Consumption consumption){
        return consumptionService.saveConsumption(consumption);
    }

     @CrossOrigin(origins = "*")
    @PutMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Consumption updateConsumtion(@RequestBody Consumption consumption){
        return consumptionService.saveConsumption(consumption);
    }

     @CrossOrigin(origins = "*")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.ACCEPTED)
    public void deleteConsumption(@PathVariable Integer id){
        consumptionService.deleteConsumption(id);
    }

}

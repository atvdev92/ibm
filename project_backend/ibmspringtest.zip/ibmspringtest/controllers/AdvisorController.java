package ibm.test.ibmspringtest.controllers;

import ibm.test.ibmspringtest.domain.Advisor;
import ibm.test.ibmspringtest.services.AdvisorService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.CrossOrigin;

import java.util.List;

@RestController
@RequestMapping(AdvisorController.ORIGIN_URL_ADVISOR)
public class AdvisorController {

    public static final String ORIGIN_URL_ADVISOR = "/api/v1/advisor";

    private final AdvisorService advisorService;

    public AdvisorController(AdvisorService advisorService) {
        this.advisorService = advisorService;
    }

    @CrossOrigin(origins = "*")
    @GetMapping
    List<Advisor> getAllAdvisor(){
        return advisorService.findAllAdvisor();
    }

    @CrossOrigin(origins = "*")
    @GetMapping("/{id}")
    public  Advisor findAdvisorById(@PathVariable Integer id){
        return advisorService.findAdvisorById(id);
    }

    @CrossOrigin(origins = "*")
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Advisor saveAdvisor(@RequestBody Advisor advisor){
        return advisorService.saveAdvisor(advisor);
    }

    @CrossOrigin(origins = "*")
    @PutMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Advisor updateAdvisor(@RequestBody Advisor advisor){
        return advisorService.saveAdvisor(advisor);
    }

    @CrossOrigin(origins = "*")
    @DeleteMapping("/{id}")
    public void deleAdvisor(@PathVariable Integer id){
        advisorService.deleteAdvisor(id);
    }
}
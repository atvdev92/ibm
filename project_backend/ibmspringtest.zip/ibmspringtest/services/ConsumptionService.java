package ibm.test.ibmspringtest.services;

import ibm.test.ibmspringtest.domain.Consumption;

import java.util.List;

public interface ConsumptionService {

    Consumption findConsumptionById(Integer id);

    List<Consumption> findAllConsumtions();

    Consumption saveConsumption(Consumption consumption);

    void deleteConsumption(Integer id);

    List<Consumption> findByCardId(Integer id);

}

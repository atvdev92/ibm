package ibm.test.ibmspringtest.services;

import ibm.test.ibmspringtest.domain.Consumption;
import ibm.test.ibmspringtest.repositories.ConsumptionRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ConsumptionServiceImpl implements ConsumptionService {

    private final ConsumptionRepository consumptionRepository;

    public ConsumptionServiceImpl(ConsumptionRepository consumptionRepository) {
        this.consumptionRepository = consumptionRepository;
    }

    @Override
    public Consumption findConsumptionById(Integer id) {
        return consumptionRepository.findById(id).get();
    }

    @Override
    public List<Consumption> findAllConsumtions() {
        return consumptionRepository.findAll();
    }

    @Override
    public Consumption saveConsumption(Consumption consumption) {
        return consumptionRepository.save(consumption);
    }

    @Override
    public void deleteConsumption(Integer id) {
        consumptionRepository.deleteById(id);
    }

    @Override
    public List<Consumption> findByCardId(Integer id) {
        return consumptionRepository.findByCardId(id);
    }
}

package ibm.test.ibmspringtest.services;

import ibm.test.ibmspringtest.domain.Advisor;
import ibm.test.ibmspringtest.repositories.AdvisorRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AdvisorServiceImpl implements AdvisorService {

    private final AdvisorRepository advisorRepository;

    public AdvisorServiceImpl(AdvisorRepository advisorRepository) {
        this.advisorRepository = advisorRepository;
    }

    @Override
    public Advisor findAdvisorById(Integer id) {
        return advisorRepository.findById(id).get();
    }

    @Override
    public List<Advisor> findAllAdvisor() {
        return advisorRepository.findAll();
    }

    @Override
    public Advisor saveAdvisor(Advisor advisor) {
        return advisorRepository.save(advisor);
    }

    @Override
    public void deleteAdvisor(Integer id) {
        advisorRepository.deleteById(id);
    }
}

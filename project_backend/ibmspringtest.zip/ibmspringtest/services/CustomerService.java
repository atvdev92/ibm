package ibm.test.ibmspringtest.services;


import ibm.test.ibmspringtest.domain.Customer;

import java.util.List;

public interface CustomerService {

    Customer findCustumerById(int id);

    List<Customer> findAllCustomers();

    Customer saveCustomer(Customer customer);

    void deleteCustomer(int id);
}

package ibm.test.ibmspringtest.services;

import ibm.test.ibmspringtest.domain.Customer;
import ibm.test.ibmspringtest.repositories.CustomerRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CustomerServiceImpl implements CustomerService {

    private final CustomerRepository customerRepository;

    public CustomerServiceImpl(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }

    @Override
    public Customer findCustumerById(int id) {

        return customerRepository.findById(id).get();
    }

    @Override
    public List<Customer> findAllCustomers() {

        return customerRepository.findAll();
    }

    @Override
    public Customer saveCustomer(Customer customer) {
        return customerRepository.save(customer);
    }

    @Override
    public void deleteCustomer(int customerId) {

        customerRepository.deleteById(customerId);
    }
}

package ibm.test.ibmspringtest.services;

import ibm.test.ibmspringtest.domain.Card;

import java.util.List;

public interface CardService {

    Card findCardById(Integer id);

    List<Card> findAllCards();

    Card saveCard(Card card);

    void deleteCard(Integer id);

    List<Card> findByCustomerId(Integer customerId);
}

package ibm.test.ibmspringtest.services;

import ibm.test.ibmspringtest.domain.Card;
import ibm.test.ibmspringtest.repositories.CardRepository;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class CardServiceImpl implements CardService {

    private final CardRepository cardRepository;

    public CardServiceImpl(CardRepository cardRepository) {
        this.cardRepository = cardRepository;
    }

    @Override
    public Card findCardById(Integer id) {
        return cardRepository.findById(id).get();
    }

    @Override
    public List<Card> findAllCards() {
        return cardRepository.findAll();
    }

    @Override
    public List<Card> findByCustomerId(Integer customerId) {
        return cardRepository.findByCustomerId(customerId);
    }

    @Override
    public Card saveCard(Card card) {
        return cardRepository.save(card);
    }

    @Override
    public void deleteCard(Integer id) {
        cardRepository.deleteById(id);
    }
}

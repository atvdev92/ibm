package ibm.test.ibmspringtest.services;

import ibm.test.ibmspringtest.domain.Advisor;

import java.util.List;

public interface AdvisorService {
    Advisor findAdvisorById(Integer id);

    List<Advisor> findAllAdvisor();

    Advisor saveAdvisor(Advisor advisor);

    void deleteAdvisor(Integer id);
}

package ibm.test.ibmspringtest.repositories;

import ibm.test.ibmspringtest.domain.Consumption;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ConsumptionRepository extends JpaRepository<Consumption, Integer> {
    List<Consumption> findByCardId(Integer cardId);
}
